# scopedb - Scoped Database
# Copyright (C) 2025 0Lier
# Licensed under the GNU GPL v3.0

from .main import Init, globals, scoped

__all__ = ["Init", "globals", "scoped"]
